package com.zorbix.fpsboost.renderer.chunk;

import java.util.concurrent.atomic.AtomicInteger;

public class ZorbixChunkScheduler {
    private final AtomicInteger pending = new AtomicInteger();

    public void beginFrame() {
        // Placeholder for the future prioritized chunk rebuild queue.
    }

    public void markDirty() {
        pending.incrementAndGet();
    }

    public int pending() {
        return pending.get();
    }
}
