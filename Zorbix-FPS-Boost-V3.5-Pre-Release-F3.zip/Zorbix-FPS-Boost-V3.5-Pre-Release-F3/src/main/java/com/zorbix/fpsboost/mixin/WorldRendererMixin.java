package com.zorbix.fpsboost.mixin;

import com.zorbix.fpsboost.FpsBoostClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @Inject(method = "setupTerrain", at = @At("HEAD"))
    private void zorbix$beginTerrain(
            Camera camera,
            Frustum frustum,
            boolean hasForcedFrustum,
            boolean spectator,
            CallbackInfo ci
    ) {
        if (FpsBoostClient.CONFIG.rendererEnabled &&
                FpsBoostClient.CONFIG.frustumPipeline) {
            FpsBoostClient.RENDERER.beginTerrainPass(frustum);
        }
    }
}
