package com.zorbix.fpsboost;

import com.zorbix.fpsboost.config.ZorbixConfig;
import com.zorbix.fpsboost.gui.ZorbixOptionsScreen;
import com.zorbix.fpsboost.renderer.ZorbixRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class FpsBoostClient implements ClientModInitializer {
    public static final ZorbixConfig CONFIG = new ZorbixConfig();
    public static final ZorbixRenderer RENDERER = new ZorbixRenderer();
    public static KeyBinding OPTIONS_KEY;

    private boolean applied;

    @Override
    public void onInitializeClient() {
        OPTIONS_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zorbix.options",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F8,
                "category.zorbix"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    private void onClientTick(MinecraftClient client) {
        while (OPTIONS_KEY.wasPressed()) {
            client.setScreen(new ZorbixOptionsScreen(client.currentScreen));
        }

        if (client.options == null || !CONFIG.rendererEnabled) {
            return;
        }

        if (!applied) {
            client.options.getParticles().setValue(CONFIG.particles);
            client.options.getCloudRenderMode().setValue(CONFIG.clouds);
            client.options.getGraphicsMode().setValue(CONFIG.graphics);
            client.options.getAo().setValue(CONFIG.ambientOcclusion);
            client.options.getEntityShadows().setValue(CONFIG.entityShadows);
            applied = true;
        }

        RENDERER.tick(client);
    }
}
