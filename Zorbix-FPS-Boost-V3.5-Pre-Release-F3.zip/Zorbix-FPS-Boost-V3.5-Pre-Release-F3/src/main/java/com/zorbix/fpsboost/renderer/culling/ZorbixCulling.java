package com.zorbix.fpsboost.renderer.culling;

import net.minecraft.client.render.Frustum;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

public final class ZorbixCulling {
    private ZorbixCulling() {
    }

    public static boolean visible(Frustum frustum, BlockPos sectionOrigin) {
        if (frustum == null || sectionOrigin == null) {
            return true;
        }

        Box section = new Box(
                sectionOrigin.getX(),
                sectionOrigin.getY(),
                sectionOrigin.getZ(),
                sectionOrigin.getX() + 16,
                sectionOrigin.getY() + 16,
                sectionOrigin.getZ() + 16
        );

        return frustum.isVisible(section);
    }
}
