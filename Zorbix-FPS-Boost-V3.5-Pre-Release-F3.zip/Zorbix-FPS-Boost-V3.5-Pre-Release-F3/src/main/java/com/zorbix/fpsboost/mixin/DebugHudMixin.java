package com.zorbix.fpsboost.mixin;

import com.zorbix.fpsboost.FpsBoostClient;
import net.minecraft.client.gui.hud.DebugHud;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(DebugHud.class)
public abstract class DebugHudMixin {
    @Inject(method = "getLeftText", at = @At("RETURN"))
    private void zorbix$addRendererInfo(CallbackInfoReturnable<List<String>> cir) {
        if (!FpsBoostClient.CONFIG.performanceHud) {
            return;
        }

        List<String> lines = cir.getReturnValue();
        lines.add("Zorbix Renderer: ACTIVE");
        lines.add("Zorbix Version: 3.5.0");
        lines.add("Zorbix Visible Sections: " +
                FpsBoostClient.RENDERER.getVisibleSections());
        lines.add("Zorbix Culled Sections: " +
                FpsBoostClient.RENDERER.getCulledSections());
    }
}
