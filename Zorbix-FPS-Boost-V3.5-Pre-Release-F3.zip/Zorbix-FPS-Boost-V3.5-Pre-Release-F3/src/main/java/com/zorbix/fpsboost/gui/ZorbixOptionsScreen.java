package com.zorbix.fpsboost.gui;

import com.zorbix.fpsboost.FpsBoostClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

public class ZorbixOptionsScreen extends Screen {
    private final Screen parent;

    public ZorbixOptionsScreen(Screen parent) {
        super(Text.literal("Zorbix Renderer"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Renderer: " + onOff(FpsBoostClient.CONFIG.rendererEnabled)),
                button -> {
                    FpsBoostClient.CONFIG.rendererEnabled =
                            !FpsBoostClient.CONFIG.rendererEnabled;
                    button.setMessage(Text.literal(
                            "Renderer: " + onOff(FpsBoostClient.CONFIG.rendererEnabled)));
                }
        ).dimensions(centerX - 100, 60, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Frustum Culling: " +
                        onOff(FpsBoostClient.CONFIG.frustumPipeline)),
                button -> {
                    FpsBoostClient.CONFIG.frustumPipeline =
                            !FpsBoostClient.CONFIG.frustumPipeline;
                    button.setMessage(Text.literal(
                            "Frustum Culling: " +
                            onOff(FpsBoostClient.CONFIG.frustumPipeline)));
                }
        ).dimensions(centerX - 100, 85, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("F3 Renderer HUD: " +
                        onOff(FpsBoostClient.CONFIG.performanceHud)),
                button -> {
                    FpsBoostClient.CONFIG.performanceHud =
                            !FpsBoostClient.CONFIG.performanceHud;
                    button.setMessage(Text.literal(
                            "F3 Renderer HUD: " +
                            onOff(FpsBoostClient.CONFIG.performanceHud)));
                }
        ).dimensions(centerX - 100, 110, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Done"),
                button -> close()
        ).dimensions(centerX - 100, 145, 200, 20).build());
    }

    private static String onOff(boolean value) {
        return value ? "ON" : "OFF";
    }

    @Override
    public void close() {
        if (client != null) {
            client.setScreen(parent);
        }
    }
}
