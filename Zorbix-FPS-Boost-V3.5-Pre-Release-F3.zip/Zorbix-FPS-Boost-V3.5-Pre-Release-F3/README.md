# Zorbix FPS Boost V3.5 Pre-Release

Minecraft 1.20.1 Fabric / Java 17.

This build adds the Zorbix renderer foundation and a real F3 renderer label.

F3 now shows:
- Zorbix Renderer: ACTIVE
- Zorbix Version: 3.5.0
- visible/cull counters from the renderer pipeline

F8 opens the Zorbix options screen.

Important:
- No adaptive render-distance changes.
- No simulation-distance changes.
- This is a renderer architecture foundation, not yet a complete Sodium replacement.

Build:
`gradle build --no-daemon`

Output:
`build/libs/zorbix-fpsboost-3.5.0.jar`
